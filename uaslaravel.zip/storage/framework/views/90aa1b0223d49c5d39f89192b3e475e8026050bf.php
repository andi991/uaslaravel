<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $pelanggan->id; ?></p>
</div>

<!-- Nama Field -->
<div class="form-group">
    <?php echo Form::label('nama', 'Nama:'); ?>

    <p><?php echo $pelanggan->nama; ?></p>
</div>

<!-- Alamat Field -->
<div class="form-group">
    <?php echo Form::label('alamat', 'Alamat:'); ?>

    <p><?php echo $pelanggan->alamat; ?></p>
</div>

<!-- Telp Field -->
<div class="form-group">
    <?php echo Form::label('telp', 'Telp:'); ?>

    <p><?php echo $pelanggan->telp; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $pelanggan->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $pelanggan->updated_at; ?></p>
</div>

