<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $pegawai->id; ?></p>
</div>

<!-- Nik Field -->
<div class="form-group">
    <?php echo Form::label('nik', 'Nik:'); ?>

    <p><?php echo $pegawai->nik; ?></p>
</div>

<!-- Nama Field -->
<div class="form-group">
    <?php echo Form::label('nama', 'Nama:'); ?>

    <p><?php echo $pegawai->nama; ?></p>
</div>

<!-- Tempat Lahir Field -->
<div class="form-group">
    <?php echo Form::label('tempat_lahir', 'Tempat Lahir:'); ?>

    <p><?php echo $pegawai->tempat_lahir; ?></p>
</div>

<!-- Tanggal Lahir Field -->
<div class="form-group">
    <?php echo Form::label('tanggal_lahir', 'Tanggal Lahir:'); ?>

    <p><?php echo $pegawai->tanggal_lahir; ?></p>
</div>

<!-- Alamat Field -->
<div class="form-group">
    <?php echo Form::label('alamat', 'Alamat:'); ?>

    <p><?php echo $pegawai->alamat; ?></p>
</div>

<!-- Email Field -->
<div class="form-group">
    <?php echo Form::label('email', 'Email:'); ?>

    <p><?php echo $pegawai->email; ?></p>
</div>

<!-- Telp Field -->
<div class="form-group">
    <?php echo Form::label('telp', 'Telp:'); ?>

    <p><?php echo $pegawai->telp; ?></p>
</div>

<!-- Foto Field -->
<div class="form-group">
    <?php echo Form::label('foto', 'Foto:'); ?>

    <p><img style="width: 200px" src="<?php echo e(asset("images/".$pegawai->foto)); ?>" alt="" class="img img-thumbnail"></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $pegawai->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $pegawai->updated_at; ?></p>
</div>

