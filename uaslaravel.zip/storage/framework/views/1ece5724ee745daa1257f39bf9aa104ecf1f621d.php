<?php $__env->startSection('content'); ?>
    <div class="content">
         <h1>You don't have permission for access this page <br/> Please contact you Superadmin!</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>