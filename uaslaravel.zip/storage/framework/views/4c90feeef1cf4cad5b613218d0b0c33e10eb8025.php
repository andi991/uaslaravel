<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $barang->id; ?></p>
</div>

<!-- Kode Field -->
<div class="form-group">
    <?php echo Form::label('kode', 'Kode:'); ?>

    <p><?php echo $barang->kode; ?></p>
</div>

<!-- Nama Field -->
<div class="form-group">
    <?php echo Form::label('nama', 'Nama:'); ?>

    <p><?php echo $barang->nama; ?></p>
</div>

<!-- Keterangan Field -->
<div class="form-group">
    <?php echo Form::label('keterangan', 'Keterangan:'); ?>

    <p><?php echo $barang->keterangan; ?></p>
</div>

<!-- Stock Field -->
<div class="form-group">
    <?php echo Form::label('stock', 'Stock:'); ?>

    <p><?php echo $barang->stock; ?></p>
</div>

<!-- Harga Field -->
<div class="form-group">
    <?php echo Form::label('harga', 'Harga:'); ?>

    <p><?php echo $barang->harga; ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $barang->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $barang->updated_at; ?></p>
</div>

